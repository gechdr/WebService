// intall express joi @joi/date sequelize mysql2 axios
// https://rapidapi.com/SAdrian/api/moviesdatabase

const express = require("express");
const Joi = require("joi").extend(require("@joi/date"));
const axios = require("axios");

const app = express();
app.set("port", 3000);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const Sequelize = require("sequelize");
const { Model, DataTypes, Op } = require("sequelize");
const sequelize = new Sequelize("", "root", "", {
	host: "localhost",
	dialect: "mysql",
	logging: false,
});

// -------------------------------------------------------

// -------------------------------------------------------

app.listen(app.get("port"), () => {
	console.log(`Server started at http://localhost:${app.get("port")}`);
});
